import test
from create_interface import Creator


def run_everything():
    creator = Creator()
    creator.run_gui()




if __name__ == '__main__':
    run_everything()
    #test.run_test()
    #test.run_test2()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
